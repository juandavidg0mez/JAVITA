package com.soccer.view;

import com.soccer.model.entity.Player;

public class viewPlayer {
       Player jugador = new Player();

}
