package com.soccer;


import java.util.Hashtable;

import com.soccer.model.entity.Team;

public class Controller {
    public Hashtable <String,Team> equipos = new Hashtable<>();
}
